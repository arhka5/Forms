﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace G16_medicamentos
{
    public class ClsLista
    {
        public string Codigo { get; set; }
        public string Nombre { get; set; }
        public string Cantidad { get; set; }
        public string Precio { get; set; }
        public float MontoInvertido { get; set; }
    }
}
